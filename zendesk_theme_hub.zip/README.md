# Help Center Navigator Hub – Zendesk Theme

Este tema convierte el proyecto **help-center-navigator-hub** en un paquete que puedes importar directamente en tu Zendesk Guide (Centro de Ayuda).

## Estructura

```
.
├── assets
│   ├── style.css    # Estilos base (Tailwind + ajustes)
│   └── script.js    # Lógica Web Widget / navegación
├── templates
│   ├── document_head.hbs
│   ├── layout.hbs
│   ├── home_page.hbs
│   └── article_page.hbs
└── manifest.json
```

## Cómo usar

1. **(Opcional) Compila tu aplicación React**  
   Si quieres montar el front‑end React completo, genera la versión de producción con:

   ```bash
   npm install
   npm run build
   ```

   Copia los archivos generados en `dist/assets/*.js` y `dist/assets/*.css` dentro de la carpeta `assets` del tema y referencia los nuevos nombres en `templates/layout.hbs`.

2. **Empaqueta el tema**  
   El archivo `zendesk_theme_hub.zip` ya está listo para subir:
   - Centro de ayuda → Personalizar diseño → **Importar tema**.

3. **Activa el tema**  
   Después de subirlo, haz clic en **Publicar**.

## Personalización rápida

- Cambia los colores en `assets/style.css` o vía Tailwind.
- Ajusta cabecera/home en `templates/home_page.hbs`.
- Añade más plantillas (`category_page.hbs`, `section_page.hbs`, etc.) si las necesitas.

¡Disfruta! ✨